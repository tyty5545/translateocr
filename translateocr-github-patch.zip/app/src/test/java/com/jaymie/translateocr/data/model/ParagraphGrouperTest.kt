package com.jaymie.translateocr.data.model

import org.junit.Assert.assertEquals
import org.junit.Test

class ParagraphGrouperTest {
    @Test
    fun joinsAdjacentLinesIntoOneParagraph() {
        val result = ParagraphGrouper.group(
            listOf(
                TextRegion("A sentence", 10, 10, 180, 30),
                TextRegion("continues here.", 12, 34, 175, 54)
            )
        )

        assertEquals(1, result.size)
        assertEquals("A sentence continues here.", result.single().text)
        assertEquals(10, result.single().top)
        assertEquals(54, result.single().bottom)
    }

    @Test
    fun keepsSeparateParagraphsWhenVerticalGapIsLarge() {
        val result = ParagraphGrouper.group(
            listOf(
                TextRegion("First paragraph", 10, 10, 180, 30),
                TextRegion("Second paragraph", 10, 70, 180, 90)
            )
        )

        assertEquals(2, result.size)
    }

    @Test
    fun doesNotMergeNeighboringColumns() {
        val result = ParagraphGrouper.group(
            listOf(
                TextRegion("Left column", 10, 10, 130, 30),
                TextRegion("Right column", 240, 10, 360, 30)
            )
        )

        assertEquals(2, result.size)
    }

    @Test
    fun ignoresBlankOrInvalidRegions() {
        val result = ParagraphGrouper.group(
            listOf(
                TextRegion("   ", 10, 10, 100, 30),
                TextRegion("Invalid", 10, 30, 10, 40),
                TextRegion("Valid", 10, 50, 100, 70)
            )
        )

        assertEquals(1, result.size)
        assertEquals("Valid", result.single().text)
    }
}
