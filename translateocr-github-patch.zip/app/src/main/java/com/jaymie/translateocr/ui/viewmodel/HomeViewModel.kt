package com.jaymie.translateocr.ui.viewmodel

import android.app.Application
import android.content.Intent
import android.graphics.Bitmap
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.google.mlkit.vision.text.Text
import com.jaymie.translateocr.data.model.Translation
import com.jaymie.translateocr.data.model.TranslationService
import com.jaymie.translateocr.data.model.ParagraphGrouper
import com.jaymie.translateocr.data.model.TextRegion
import com.jaymie.translateocr.data.model.TranslatedParagraph
import com.jaymie.translateocr.data.repository.FirestoreRepository
import com.jaymie.translateocr.data.repository.OCRRepository
import com.jaymie.translateocr.data.repository.TranslationHistoryRepository
import com.jaymie.translateocr.data.repository.TranslationRepository
import com.jaymie.translateocr.data.service.ScreenCaptureService
import com.jaymie.translateocr.service.TranslateAccessibilityService
import com.jaymie.translateocr.utils.DeepLConstants
import com.jaymie.translateocr.utils.Event
import com.jaymie.translateocr.utils.FloatingButtonManager
import com.jaymie.translateocr.utils.GoogleLanguages
import com.jaymie.translateocr.utils.OverlayManager
import com.jaymie.translateocr.utils.PermissionUtils
import com.jaymie.translateocr.utils.PreferencesManager
import com.jaymie.translateocr.utils.ScreenCaptureManager
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * ViewModel for handling translation operations and UI state in the Home screen.
 * Uses:
 * - ViewBinding for UI interactions
 * - Coroutines for async operations
 * - LiveData for state management
 * - ML Kit for OCR and translation
 */
class HomeViewModel(application: Application) : AndroidViewModel(application) {
    private val screenCaptureManager = ScreenCaptureManager(application)
    private val ocrRepository = OCRRepository(application)
    private val translationRepository = TranslationRepository()
    private val preferencesManager = PreferencesManager(application)
    private val translationHistoryRepository = TranslationHistoryRepository()
    private val floatingButtonManager = FloatingButtonManager(application)
    private val firestoreRepository = FirestoreRepository()

    // UI State LiveData
    private val _showFloatingButton = MutableLiveData<Boolean>()
    val showFloatingButton: LiveData<Boolean> = _showFloatingButton

    private val _toastMessage = MutableLiveData<String?>()
    val toastMessage: LiveData<String?> = _toastMessage

    private val _ocrResult = MutableLiveData<List<Text.TextBlock>>()
    val ocrResult: LiveData<List<Text.TextBlock>> = _ocrResult

    // Language State
    private val _sourceLanguage = MutableLiveData<String>()
    val sourceLanguage: LiveData<String> = _sourceLanguage

    private val _targetLanguage = MutableLiveData<String?>()
    val targetLanguage: MutableLiveData<String?> = _targetLanguage

    private val _sourceLanguageText = MutableLiveData<String>()
    val sourceLanguageText: LiveData<String> = _sourceLanguageText

    private val _targetLanguageText = MutableLiveData<String?>()
    val targetLanguageText: MutableLiveData<String?> = _targetLanguageText

    // Service State
    private val _selectedService = MutableLiveData(TranslationService.GOOGLE_TRANSLATE)
    val selectedService: LiveData<TranslationService> = _selectedService

    private val _showApiKeyDialog = MutableLiveData<Event<TranslationService>>()
    val showApiKeyDialog: LiveData<Event<TranslationService>> = _showApiKeyDialog

    private val _validationResult = MutableLiveData<ValidationResult>()
    val validationResult: LiveData<ValidationResult> = _validationResult

    private var isScreenCaptureActive = false

    private val _isHighPrecisionEnabled = MutableLiveData<Boolean>()
    val isHighPrecisionEnabled: LiveData<Boolean> = _isHighPrecisionEnabled

    private var isProcessingTranslation = false

    init {
        setDefaultLanguages()
        observeAccessibilityService()
    }

    /**
     * Starts screen capture service and projection.
     * Uses coroutines for async operations.
     */
    fun startScreenCapture(resultCode: Int, data: Intent) {
        viewModelScope.launch {
            try {
                ScreenCaptureService.startService(getApplication())
                delay(100)
                screenCaptureManager.startProjection(resultCode, data)
                _showFloatingButton.value = true
                isScreenCaptureActive = true
            } catch (e: Exception) {
                _toastMessage.postValue("Error starting screen capture: ${e.message}")
            }
        }
    }

    fun onFloatingButtonClicked() {
        viewModelScope.launch {
            try {
                OverlayManager.getInstance().showOverlay(getApplication())
                OverlayManager.getInstance().showLoading(true)
                
                val bitmap = screenCaptureManager.captureScreen()
                bitmap?.let { processScreenCapture(it) }
            } catch (e: Exception) {
                _toastMessage.postValue("Error: ${e.message}")
                OverlayManager.getInstance().showLoading(false)
            }
        }
    }

    private suspend fun processScreenCapture(bitmap: Bitmap) {
        val textBlocks = ocrRepository.performOCR(bitmap)
        
        if (textBlocks.isEmpty()) {
            _toastMessage.postValue("No text detected")
            OverlayManager.getInstance().showLoading(false)
            return
        }

        // Check API key requirements
        when (selectedService.value) {
            TranslationService.GOOGLE_TRANSLATE_API -> {
                val apiKey = preferencesManager.getGoogleApiKey()
                if (apiKey.isNullOrBlank()) {
                    _toastMessage.postValue("Google Translate API key is not set")
                    _showApiKeyDialog.value = Event(TranslationService.GOOGLE_TRANSLATE_API)
                    OverlayManager.getInstance().showLoading(false)
                    return
                }
                processTranslation(textBlocks)
            }
            TranslationService.DEEPL_API -> {
                val apiKey = preferencesManager.getDeepLApiKey()
                if (apiKey.isNullOrBlank()) {
                    _toastMessage.postValue("DeepL API key is not set")
                    _showApiKeyDialog.value = Event(TranslationService.DEEPL_API)
                    OverlayManager.getInstance().showLoading(false)
                    return
                }
                processTranslation(textBlocks)
            }
            else -> processTranslation(textBlocks)
        }
    }

    private suspend fun processTranslation(textBlocks: List<Text.TextBlock>) {
        if (!isScreenCaptureActive || isProcessingTranslation) return
        isProcessingTranslation = true

        try {
            val service = selectedService.value ?: TranslationService.GOOGLE_TRANSLATE
            if (service == TranslationService.OFFLINE && !isModelDownloaded()) {
                throw IllegalStateException("Language model not downloaded. Please download it first.")
            }

            // Reconstruct paragraphs before translation so each request has sentence context.
            val validLines = OverlayManager.getInstance().getValidTextBlocks(textBlocks, getApplication())
            val regions = validLines.mapNotNull { line ->
                val bounds = line.boundingBox ?: return@mapNotNull null
                TextRegion(line.text, bounds.left, bounds.top, bounds.right, bounds.bottom)
            }
            val paragraphs = ParagraphGrouper.group(regions)
            if (paragraphs.isEmpty()) {
                _toastMessage.postValue("No readable text found")
                OverlayManager.getInstance().showLoading(false)
                return
            }

            val translations = translateParagraphTexts(paragraphs.map { it.text })
            val translatedParagraphs = paragraphs.zip(translations).map { (paragraph, translated) ->
                TranslatedParagraph(
                    originalText = paragraph.text,
                    translatedText = translated,
                    left = paragraph.left,
                    top = paragraph.top,
                    right = paragraph.right,
                    bottom = paragraph.bottom
                )
            }
            OverlayManager.getInstance().updateOverlayWithParagraphs(translatedParagraphs)
            saveParagraphHistory(paragraphs.map { it.text }, translations)
            updateWordCountForParagraphs(paragraphs.map { it.text })
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleTranslationError(e, textBlocks)
        } finally {
            isProcessingTranslation = false
        }
    }

    /** Cloud providers receive all visible paragraphs in one HTTP batch. */
    private suspend fun translateParagraphTexts(paragraphs: List<String>): List<String> {
        if (paragraphs.isEmpty()) return emptyList()
        val service = selectedService.value ?: TranslationService.GOOGLE_TRANSLATE
        val source = sourceLanguage.value ?: "en"
        val target = targetLanguage.value ?: "ja"

        return when (service) {
            TranslationService.OFFLINE -> paragraphs.map { paragraph ->
                translationRepository.translateOffline(paragraph, source, target)
            }
            TranslationService.GOOGLE_TRANSLATE,
            TranslationService.GOOGLE_TRANSLATE_API -> {
                val apiMode = service == TranslationService.GOOGLE_TRANSLATE_API
                translationRepository.translateWithGoogleBatch(
                    texts = paragraphs,
                    sourceLanguage = source,
                    targetLanguage = target,
                    apiKey = if (apiMode) preferencesManager.getGoogleApiKey() else null,
                    isApiKeyService = apiMode
                )
            }
            TranslationService.DEEPL,
            TranslationService.DEEPL_API -> {
                val apiMode = service == TranslationService.DEEPL_API
                translationRepository.translateWithDeepLBatch(
                    texts = paragraphs,
                    sourceLanguage = source,
                    targetLanguage = target,
                    apiKey = if (apiMode) preferencesManager.getDeepLApiKey() else null,
                    isApiKeyService = apiMode
                )
            }
        }
    }

    private suspend fun saveParagraphHistory(originalParagraphs: List<String>, translations: List<String>) {
        val historyItem = Translation(
            id = System.currentTimeMillis().toString(),
            originalText = originalParagraphs.joinToString("\n\n"),
            translatedText = translations.joinToString("\n\n"),
            fromLanguage = sourceLanguage.value ?: "en",
            toLanguage = targetLanguage.value ?: "ja"
        )
        translationHistoryRepository.saveTranslation(historyItem)
    }

    private suspend fun updateWordCountForParagraphs(paragraphs: List<String>) {
        val wordCount = paragraphs.sumOf { paragraph ->
            paragraph.trim().split(Regex("\\s+")).count { it.isNotBlank() }
        }
        if (wordCount > 0) {
            preferencesManager.incrementTranslatedWords(wordCount)
            runCatching { firestoreRepository.updateUserStats(wordCount) }
                .onFailure { Log.w("HomeViewModel", "Could not sync translation statistics", it) }
        }
    }

    fun setTranslationService(service: TranslationService) {
        val previousService = selectedService.value ?: TranslationService.GOOGLE_TRANSLATE
        _selectedService.value = service

        when (service) {
            TranslationService.GOOGLE_TRANSLATE_API -> {
                if (preferencesManager.getGoogleApiKey().isNullOrBlank()) {
                    _showApiKeyDialog.value = Event(service)
                    _selectedService.value = previousService
                    return
                }
            }
            TranslationService.DEEPL_API -> {
                if (preferencesManager.getDeepLApiKey().isNullOrBlank()) {
                    _showApiKeyDialog.value = Event(service)
                    _selectedService.value = previousService
                    return
                }
            }
            TranslationService.GOOGLE_TRANSLATE,
            TranslationService.DEEPL,
            TranslationService.OFFLINE -> {
                // No API key validation needed for these services
            }
        }

        setDefaultLanguagesForService(service)
    }

    fun validateAndSaveApiKey(service: TranslationService, apiKey: String) {
        viewModelScope.launch {
            try {
                _validationResult.value = ValidationResult.Loading

                when (service) {
                    TranslationService.GOOGLE_TRANSLATE_API -> {
                        if (translationRepository.testGoogleTranslate(apiKey)) {
                            preferencesManager.saveGoogleApiKey(apiKey)
                            _selectedService.value = service
                            _validationResult.value = ValidationResult.Success
                        } else {
                            _validationResult.value = ValidationResult.Error("Invalid API key")
                        }
                    }
                    TranslationService.DEEPL_API -> {
                        if (translationRepository.testDeepL(apiKey)) {
                            preferencesManager.saveDeepLApiKey(apiKey)
                            _selectedService.value = service
                            _validationResult.value = ValidationResult.Success
                        } else {
                            _validationResult.value = ValidationResult.Error("Invalid API key")
                        }
                    }
                    else -> _validationResult.value = ValidationResult.Error("Invalid service type")
                }
            } catch (e: Exception) {
                _validationResult.value = ValidationResult.Error(e.message ?: "Unknown error")
            }
        }
    }

    fun setSourceLanguage(code: String, displayText: String) {
        _sourceLanguage.value = code
        _sourceLanguageText.value = displayText
    }

    fun setTargetLanguage(code: String, displayText: String) {
        _targetLanguage.value = code
        _targetLanguageText.value = displayText
    }

    fun swapLanguages() {
        val tempSourceCode = _sourceLanguage.value
        val tempSourceText = _sourceLanguageText.value
        
        _sourceLanguage.value = _targetLanguage.value
        _sourceLanguageText.value = _targetLanguageText.value
        
        _targetLanguage.value = tempSourceCode
        _targetLanguageText.value = tempSourceText
    }

    private fun setDefaultLanguages() {
        setSourceLanguage("en", "English")
        setTargetLanguage("ja", "Japanese")
    }

    private fun setDefaultLanguagesForService(service: TranslationService) {
        val isDeepL = service == TranslationService.DEEPL || service == TranslationService.DEEPL_API
        
        // Use the language's name property instead of code for display
        val sourceLanguage = if (isDeepL) {
            DeepLConstants.SUPPORTED_SOURCE_LANGUAGES.find { it.code == "EN" }
        } else {
            GoogleLanguages.SUPPORTED_LANGUAGES.find { it.code == "en" }
        }

        val targetLanguage = if (isDeepL) {
            DeepLConstants.SUPPORTED_TARGET_LANGUAGES.find { it.code == "JA" }
        } else {
            GoogleLanguages.SUPPORTED_LANGUAGES.find { it.code == "ja" }
        }

        sourceLanguage?.let { setSourceLanguage(it.code, it.name) }
        targetLanguage?.let { setTargetLanguage(it.code, it.name) }
    }

    private fun handleTranslationError(e: Exception, textBlocks: List<Text.TextBlock>) {
        _toastMessage.postValue("Translation failed: ${e.message}")
        OverlayManager.getInstance().updateOverlayText(textBlocks)
    }

    fun hasScreenRecordingPermission(): Boolean = PermissionUtils.hasScreenRecordingPermission()

    override fun onCleared() {
        super.onCleared()
        isProcessingTranslation = false
        ocrRepository.close()
        translationRepository.close()
        if (isScreenCaptureActive) {
            clearTranslationState()
            floatingButtonManager.cleanup()
        }
        // Remove the observer properly
        accessibilityObserver?.let {
            TranslateAccessibilityService.screenText.removeObserver(it)
        }
        accessibilityObserver = null
    }

    sealed class ValidationResult {
        data object Loading : ValidationResult()
        data object Success : ValidationResult()
        data class Error(val message: String) : ValidationResult()
    }

    fun onApiKeyDialogDismissed(service: TranslationService) {
        when (service) {
            TranslationService.GOOGLE_TRANSLATE_API -> {
                if (preferencesManager.getGoogleApiKey().isNullOrBlank()) {
                    _toastMessage.value = "Google Translate API key is not set"
                }
            }
            TranslationService.DEEPL_API -> {
                if (preferencesManager.getDeepLApiKey().isNullOrBlank()) {
                    _toastMessage.value = "DeepL API key is not set"
                }
            }
            TranslationService.GOOGLE_TRANSLATE,
            TranslationService.DEEPL,
            TranslationService.OFFLINE -> {
                // These services don't require API keys, so no action needed
            }
        }
    }

    fun clearTranslationState() {
        viewModelScope.launch {
            try {
                if (isScreenCaptureActive) {
                    isProcessingTranslation = false
                    screenCaptureManager.stopProjection()
                    isScreenCaptureActive = false
                    _showFloatingButton.value = false
                    floatingButtonManager.removeFloatingButton()
                    OverlayManager.getInstance().removeOverlay()
                    _ocrResult.value = emptyList()
                    _toastMessage.postValue(null)
                    getApplication<Application>().stopService(Intent(getApplication(), ScreenCaptureService::class.java))
                }
            } catch (e: Exception) {
                // Handle any cleanup errors silently
            }
        }
    }

    fun stopScreenCapture() {
        viewModelScope.launch {
            try {
                screenCaptureManager.stopProjection()
                isScreenCaptureActive = false
                _showFloatingButton.value = false
                floatingButtonManager.removeFloatingButton()
                getApplication<Application>().stopService(Intent(getApplication(), ScreenCaptureService::class.java))
            } catch (e: Exception) {
                _toastMessage.postValue("Error stopping screen capture: ${e.message}")
            }
        }
    }

    fun checkState() {
        if (!isScreenCaptureActive) {
            _showFloatingButton.value = false
        }
    }

    private fun processHighPrecisionText(textBlocks: List<TranslateAccessibilityService.TextBlock>) {
        if (!isScreenCaptureActive || isProcessingTranslation || textBlocks.isEmpty()) return

        viewModelScope.launch {
            isProcessingTranslation = true
            try {
                if (selectedService.value == TranslationService.OFFLINE && !isModelDownloaded()) {
                    throw IllegalStateException("Language model not downloaded. Please download it first.")
                }
                val regions = textBlocks.mapNotNull { block ->
                    val bounds = block.bounds
                    if (bounds.width() <= 0 || bounds.height() <= 0 || block.text.isBlank()) {
                        null
                    } else {
                        TextRegion(block.text, bounds.left, bounds.top, bounds.right, bounds.bottom)
                    }
                }
                val paragraphs = ParagraphGrouper.group(regions)
                if (paragraphs.isEmpty()) return@launch

                val translations = translateParagraphTexts(paragraphs.map { it.text })
                val translatedParagraphs = paragraphs.zip(translations).map { (paragraph, translated) ->
                    TranslatedParagraph(
                        originalText = paragraph.text,
                        translatedText = translated,
                        left = paragraph.left,
                        top = paragraph.top,
                        right = paragraph.right,
                        bottom = paragraph.bottom
                    )
                }
                OverlayManager.getInstance().updateOverlayWithParagraphs(translatedParagraphs, subtractStatusBar = false)
                saveParagraphHistory(paragraphs.map { it.text }, translations)
                updateWordCountForParagraphs(paragraphs.map { it.text })
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (isScreenCaptureActive) {
                    _toastMessage.postValue("Translation failed: ${e.message}")
                }
            } finally {
                isProcessingTranslation = false
            }
        }
    }

    private suspend fun isModelDownloaded(): Boolean {
        return translationRepository.isModelDownloaded(
            sourceLanguage = sourceLanguage.value ?: "en",
            targetLanguage = targetLanguage.value ?: "ja"
        )
    }

    // Store the observer reference for proper cleanup
    private var accessibilityObserver: ((List<TranslateAccessibilityService.TextBlock>) -> Unit)? = null

    private fun observeAccessibilityService() {
        accessibilityObserver = { textBlocks ->
            if (isHighPrecisionEnabled.value == true) {
                processHighPrecisionText(textBlocks)
            }
        }
        accessibilityObserver?.let {
            TranslateAccessibilityService.screenText.observeForever(it)
        }
    }

}

