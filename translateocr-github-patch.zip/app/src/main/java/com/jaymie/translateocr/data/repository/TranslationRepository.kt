package com.jaymie.translateocr.data.repository

import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap

/** Translation backend for Google Cloud Translation, DeepL and on-device ML Kit. */
class TranslationRepository {
    companion object {
        private const val GOOGLE_TRANSLATE_URL = "https://translation.googleapis.com/language/translate/v2"
        private const val DEEPL_URL = "https://api-free.deepl.com/v2/translate"

        // Kept for compatibility with the app's existing built-in service modes.
        // User-supplied API keys always take precedence for the corresponding API mode.
        private const val GOOGLE_API_KEY = "AIzaSyBbqNXjC71FoTXuyRrhF-rzLts65qArJyc"
        private const val DEEPL_API_KEY = "09993180-00e7-4bc8-abe3-c63a71e1d05d:fx"

        private const val TEST_TEXT = "Hello"
        private const val TIMEOUT_MS = 15_000
        private const val MAX_BATCH_SIZE = 50
    }

    private val translators = ConcurrentHashMap<String, Translator>()

    private fun translatorFor(sourceLanguage: String, targetLanguage: String): Translator {
        val source = TranslateLanguage.fromLanguageTag(sourceLanguage) ?: sourceLanguage
        val target = TranslateLanguage.fromLanguageTag(targetLanguage) ?: targetLanguage
        val key = "$source->$target"
        return translators.getOrPut(key) {
            val options = TranslatorOptions.Builder()
                .setSourceLanguage(source)
                .setTargetLanguage(target)
                .build()
            Translation.getClient(options)
        }
    }

    suspend fun translateOffline(
        text: String,
        sourceLanguage: String,
        targetLanguage: String
    ): String {
        if (text.isBlank()) return ""
        return try {
            translatorFor(sourceLanguage, targetLanguage).translate(text).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            throw IllegalStateException("Offline translation failed: ${e.message}", e)
        }
    }

    suspend fun isModelDownloaded(sourceLanguage: String, targetLanguage: String): Boolean {
        return try {
            // ML Kit's API ensures the model is available; an already-installed model returns quickly.
            translatorFor(sourceLanguage, targetLanguage).downloadModelIfNeeded().await()
            true
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            false
        }
    }

    /** Translates many strings in one Google request (up to 50 strings per HTTP call). */
    suspend fun translateWithGoogleBatch(
        texts: List<String>,
        sourceLanguage: String,
        targetLanguage: String,
        apiKey: String? = null,
        isApiKeyService: Boolean = false
    ): List<String> {
        if (texts.isEmpty()) return emptyList()
        val key = if (isApiKeyService) {
            require(!apiKey.isNullOrBlank()) { "Google Translate API key is required" }
            apiKey
        } else {
            GOOGLE_API_KEY
        }
        return texts.chunked(MAX_BATCH_SIZE).flatMap { chunk ->
            performGoogleBatch(chunk, sourceLanguage, targetLanguage, key)
        }
    }

    suspend fun translateWithGoogle(
        text: String,
        sourceLanguage: String,
        targetLanguage: String,
        apiKey: String? = null,
        isApiKeyService: Boolean = false
    ): String = translateWithGoogleBatch(
        listOf(text), sourceLanguage, targetLanguage, apiKey, isApiKeyService
    ).first()

    /** DeepL accepts repeated `text` form fields, so a paragraph batch is one request. */
    suspend fun translateWithDeepLBatch(
        texts: List<String>,
        sourceLanguage: String,
        targetLanguage: String,
        apiKey: String? = null,
        isApiKeyService: Boolean = false
    ): List<String> {
        if (texts.isEmpty()) return emptyList()
        val key = if (isApiKeyService) {
            require(!apiKey.isNullOrBlank()) { "DeepL API key is required" }
            apiKey
        } else {
            DEEPL_API_KEY
        }
        return texts.chunked(MAX_BATCH_SIZE).flatMap { chunk ->
            performDeepLBatch(chunk, sourceLanguage, targetLanguage, key)
        }
    }

    suspend fun translateWithDeepL(
        text: String,
        sourceLanguage: String,
        targetLanguage: String,
        apiKey: String? = null,
        isApiKeyService: Boolean = false
    ): String = translateWithDeepLBatch(
        listOf(text), sourceLanguage, targetLanguage, apiKey, isApiKeyService
    ).first()

    private suspend fun performGoogleBatch(
        texts: List<String>,
        sourceLanguage: String,
        targetLanguage: String,
        apiKey: String
    ): List<String> = withContext(Dispatchers.IO) {
        val body = JSONObject().apply {
            put("q", JSONArray(texts))
            put("source", sourceLanguage.lowercase())
            put("target", targetLanguage.lowercase())
            put("format", "text")
        }
        val url = "$GOOGLE_TRANSLATE_URL?key=${URLEncoder.encode(apiKey, "UTF-8")}"
        val response = executeRequest(url, "POST", "application/json; charset=UTF-8", body.toString())
        val translations = JSONObject(response)
            .getJSONObject("data")
            .getJSONArray("translations")
        require(translations.length() == texts.size) {
            "Google Translate returned ${translations.length()} results for ${texts.size} inputs"
        }
        List(translations.length()) { index ->
            translations.getJSONObject(index).getString("translatedText")
        }
    }

    private suspend fun performDeepLBatch(
        texts: List<String>,
        sourceLanguage: String,
        targetLanguage: String,
        apiKey: String
    ): List<String> = withContext(Dispatchers.IO) {
        val postData = buildString {
            texts.forEach { text ->
                append("text=").append(URLEncoder.encode(text, "UTF-8")).append('&')
            }
            append("source_lang=").append(URLEncoder.encode(sourceLanguage.uppercase(), "UTF-8"))
            append("&target_lang=").append(URLEncoder.encode(targetLanguage.uppercase(), "UTF-8"))
        }
        val response = executeRequest(
            url = DEEPL_URL,
            method = "POST",
            contentType = "application/x-www-form-urlencoded",
            body = postData,
            authorization = "DeepL-Auth-Key $apiKey"
        )
        val translations = JSONObject(response).getJSONArray("translations")
        require(translations.length() == texts.size) {
            "DeepL returned ${translations.length()} results for ${texts.size} inputs"
        }
        List(translations.length()) { index -> translations.getJSONObject(index).getString("text") }
    }

    private fun executeRequest(
        url: String,
        method: String,
        contentType: String,
        body: String,
        authorization: String? = null
    ): String {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = TIMEOUT_MS
            readTimeout = TIMEOUT_MS
            setRequestProperty("Content-Type", contentType)
            setRequestProperty("Accept", "application/json")
            authorization?.let { setRequestProperty("Authorization", it) }
            doOutput = true
        }

        try {
            connection.outputStream.use { output -> output.write(body.toByteArray(Charsets.UTF_8)) }
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val responseBody = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (status !in 200..299) {
                val detail = runCatching { JSONObject(responseBody).optJSONObject("error")?.optString("message") }.getOrNull()
                throw IllegalStateException(detail?.takeIf { it.isNotBlank() } ?: "Translation HTTP error: $status")
            }
            return responseBody
        } finally {
            connection.disconnect()
        }
    }

    suspend fun testGoogleTranslate(apiKey: String): Boolean = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) return@withContext false
        try {
            val body = JSONObject().apply {
                put("q", TEST_TEXT)
                put("source", "en")
                put("target", "ja")
            }
            executeRequest(
                url = "$GOOGLE_TRANSLATE_URL?key=${URLEncoder.encode(apiKey, "UTF-8")}",
                method = "POST",
                contentType = "application/json; charset=UTF-8",
                body = body.toString()
            )
            true
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            false
        }
    }

    suspend fun testDeepL(apiKey: String): Boolean = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) return@withContext false
        try {
            val postData = "text=${URLEncoder.encode(TEST_TEXT, "UTF-8")}&source_lang=EN&target_lang=JA"
            executeRequest(
                url = DEEPL_URL,
                method = "POST",
                contentType = "application/x-www-form-urlencoded",
                body = postData,
                authorization = "DeepL-Auth-Key $apiKey"
            )
            true
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            false
        }
    }

    /** Releases ML Kit native resources when the owning ViewModel is destroyed. */
    fun close() {
        translators.values.forEach { translator -> runCatching { translator.close() } }
        translators.clear()
    }
}
