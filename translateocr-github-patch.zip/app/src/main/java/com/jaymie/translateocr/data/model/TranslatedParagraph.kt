package com.jaymie.translateocr.data.model

/** A group of visually adjacent OCR/accessibility lines that should be translated in context. */
data class TextRegion(
    val text: String,
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int
) {
    val width: Int get() = right - left
    val height: Int get() = bottom - top
}

/** A paragraph and its screen bounds, together with the translated result. */
data class TranslatedParagraph(
    val originalText: String,
    val translatedText: String,
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int
)

/**
 * Reconstructs paragraphs from OCR/accessibility line rectangles.
 * Lines are joined only when they are close vertically and share approximately
 * the same left edge. This avoids merging adjacent columns into one paragraph.
 */
object ParagraphGrouper {
    fun group(regions: List<TextRegion>): List<TextRegion> {
        val valid = regions.asSequence()
            .filter { it.text.isNotBlank() && it.width > 0 && it.height > 0 }
            .sortedWith(compareBy<TextRegion> { it.top }.thenBy { it.left })
            .toList()
        if (valid.isEmpty()) return emptyList()

        val result = mutableListOf<TextRegion>()
        var currentLines = mutableListOf(valid.first())
        var currentLeft = valid.first().left
        var currentRight = valid.first().right
        var currentTop = valid.first().top
        var currentBottom = valid.first().bottom

        fun flush() {
            if (currentLines.isEmpty()) return
            result += TextRegion(
                text = currentLines.joinToString(" ") { it.text.trim() },
                left = currentLeft,
                top = currentTop,
                right = currentRight,
                bottom = currentBottom
            )
        }

        for (next in valid.drop(1)) {
            val previous = currentLines.last()
            val verticalGap = next.top - previous.bottom
            val typicalHeight = maxOf(previous.height, next.height)
            val maxGap = maxOf(8, (typicalHeight * 0.85f).toInt())
            val alignmentTolerance = maxOf(40, typicalHeight * 2)
            val sameColumn = kotlin.math.abs(next.left - currentLeft) <= alignmentTolerance
            val minOverlap = -(typicalHeight * 0.20f).toInt()
            val belongsToParagraph = verticalGap in minOverlap..maxGap && sameColumn

            if (belongsToParagraph) {
                currentLines += next
                currentLeft = minOf(currentLeft, next.left)
                currentRight = maxOf(currentRight, next.right)
                currentTop = minOf(currentTop, next.top)
                currentBottom = maxOf(currentBottom, next.bottom)
            } else {
                flush()
                currentLines = mutableListOf(next)
                currentLeft = next.left
                currentRight = next.right
                currentTop = next.top
                currentBottom = next.bottom
            }
        }
        flush()
        return result
    }
}
